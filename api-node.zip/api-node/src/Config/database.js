const {Sequelize} = require('sequelize');

const sequelize = new Sequelize ({
    dialect:'sqlite', 
    storage:'database.sqlite',
})

sequelize.authenticate()
            .then(()=>{
                console.log('Conectando...')
                console.log('Você está logado!')
                return sequelize.sync();
            })
            .catch(err =>{
                console.error('Erro: 404, programador não encontrado!', err)
                console.error('Tente novamente!', err)
            })
module.exports = sequelize;