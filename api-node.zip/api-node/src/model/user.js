const { Sequelize, DataTypes } = require("sequelize")
const sequelize = require ('../Config/database')

const User = sequelize.define('Users',
    {
        id: {
            type: DataTypes.UUIDV4,
            primaryKey: true
        },
        username:{
            type: DataTypes.STRING,
            AllowNull: false
        },
        password:{
            type: DataTypes.STRING,
            AllowNull: false
        }
    }   
)

module.exports = User;