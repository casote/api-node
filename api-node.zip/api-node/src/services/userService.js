const bcrypt = require ('bcrypt');
const UserRepository = require('../repositories/userRepositories');
const userRepositories = require('../repositories/userRepositories');
const {v4: UUIDV4} = require ('uuid')


const SECRET_KEY = '123456'

class UserService {
    async getAll(){
        userRepositories.findAll();
    }
    async getByUserName(username){
        return userRepositories.findByUserName(username);
    }
    async register(username, password) {
        if(username === ""){
            throw new Error('Preencha o campo de nome de usuário');            
        }
        if(password === ""){
            throw new Error ('Preencha o campo de nome de usuário');
        }
        const user = await this.getByUserName(username);
        if(user){
            throw new Error('Nome de usuário indisponível, escolha outro!');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const id = UUIDV4();
        return await userRepositories.createUser({
            id,
            username,
            password: hashedPassword
        });
    }
}
module.exports = new UserService();