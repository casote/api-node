const express = require ('express');
const userService = require ('../services/userService');

const router = express.Router();

router.get ('/', async (req, res) =>{
    try
    {
    const users = await userService.getAll();
    res.json(users);
    }catch(err)
    {
        res.status(400).json({error:err.message});
    }
});

router.post ('/', async (req, res) => {
    const {username, password } = req.body;
    const user = await userService.register(username, password);
    res.json(user);
});
module.exports = router;